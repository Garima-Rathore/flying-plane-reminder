# ✈️ Calendar Plane

A tiny macOS desktop companion that watches your Google Calendar and sends a cute plane flying across your screen shortly before a meeting.

The plane uses the illustration from the supplied reference screenshot, with a new ribbon/banner rendered behind it.

## What it does

- Connects to your Google Calendar with OAuth 2.0.
- Checks your primary calendar every 30 seconds.
- Finds the next upcoming timed event.
- When the event is within the configured reminder window (default: **5 minutes**), a plane flies from the left edge to the right edge of your screen.
- The banner shows the meeting title, time, and a friendly countdown.
- The overlay stays above normal windows, ignores mouse clicks, and can appear across macOS Spaces.
- A small menu-bar app lets you pause/resume and quit.

## Requirements

- macOS
- Python 3.10+
- A Google account with Google Calendar
- A Google Cloud project with the Google Calendar API enabled

Google's current Python quickstart recommends a **Desktop app** OAuth client and the `google-api-python-client`, `google-auth-httplib2`, and `google-auth-oauthlib` packages. See the official guide: https://developers.google.com/workspace/calendar/api/quickstart/python

## 1. Clone the repo

```bash
git clone https://github.com/YOUR_USERNAME/calendar-plane.git
cd calendar-plane
```

## 2. Create a virtual environment

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 3. Set up Google Calendar

1. Open Google Cloud Console.
2. Create/select a project.
3. Enable **Google Calendar API**.
4. Configure the Google Auth Platform / OAuth consent screen.
5. Create an OAuth client with application type **Desktop app**.
6. Download the JSON credentials.
7. Rename the downloaded file to `credentials.json`.
8. Put `credentials.json` in the root of this repo.

Do **not** commit `credentials.json` or `token.json`. They are already ignored by `.gitignore`.

On the first run, your browser opens and asks you to authorize Calendar read-only access. Google stores the resulting token locally so you do not have to authorize every time.

## 4. Run

```bash
source .venv/bin/activate
python app.py
```

The first launch may ask you to sign in to Google.

To test the animation without waiting for a real meeting:

```bash
python app.py --demo
```

## Configuration

Environment variables:

| Variable | Default | Meaning |
|---|---:|---|
| `REMINDER_MINUTES` | `5` | Show the plane when an event is this many minutes away or less |
| `CHECK_INTERVAL` | `30` | Calendar polling interval in seconds |
| `FLIGHT_SECONDS` | `10` | How long the plane takes to cross the screen |
| `FLIGHT_HEIGHT` | `260` | Approximate overlay height in pixels |

Example:

```bash
REMINDER_MINUTES=10 FLIGHT_SECONDS=14 python app.py
```

## Menu bar

Once running, the app places a small ✈️ icon in the macOS menu bar:

- **Pause / Resume**
- **Fly demo**
- **Quit**

## Security

This project only requests:

`https://www.googleapis.com/auth/calendar.readonly`

It never creates, edits, or deletes calendar events.

Keep these files private:

- `credentials.json`
- `token.json`

## Project structure

```text
calendar-plane/
├── app.py
├── calendar_client.py
├── overlay.py
├── requirements.txt
├── .gitignore
├── LICENSE
├── README.md
└── assets/
    └── plane.png
```

## Notes

This is intentionally a local desktop app rather than a web service. Your Google OAuth token stays on your Mac, and the calendar data is used only to decide when and what to display.

The macOS overlay uses PyObjC/AppKit so the animation can float above normal windows without stealing keyboard focus.
