from __future__ import annotations

import argparse
import datetime as dt
import os
import threading

import rumps
from AppKit import NSOperationQueue, NSWorkspace
from Foundation import NSObject

from calendar_client import CalendarClient
from overlay import PlaneOverlay


REMINDER_MINUTES = int(os.getenv("REMINDER_MINUTES", "5"))
CHECK_INTERVAL = int(os.getenv("CHECK_INTERVAL", "30"))
FLIGHT_SECONDS = float(os.getenv("FLIGHT_SECONDS", "10"))


def _minutes_until(when: dt.datetime) -> int:
    now = dt.datetime.now(dt.timezone.utc)
    seconds = max(0, (when.astimezone(dt.timezone.utc) - now).total_seconds())
    return int((seconds + 59) // 60)


class CalendarPlaneApp(rumps.App):
    def __init__(self, demo: bool = False):
        super().__init__("✈️", quit_button=None)
        self.demo = demo
        self.paused = False
        self.calendar = CalendarClient()
        self.overlay = PlaneOverlay()
        self.seen = set()
        self.authorized = False
        self.status_item = rumps.MenuItem("Connecting to Google Calendar…")
        self.pause_item = rumps.MenuItem("Pause", callback=self.toggle_pause)
        self.menu = [
            self.status_item,
            None,
            self.pause_item,
            rumps.MenuItem("Fly demo", callback=self.fly_demo),
            None,
            rumps.MenuItem("Quit", callback=rumps.quit_application),
        ]

        threading.Thread(target=self._authorize, daemon=True).start()
        self.timer = rumps.Timer(self._tick, CHECK_INTERVAL)
        self.timer.start()

    def _authorize(self):
        try:
            self.calendar.authorize()
            self.authorized = True
            self.status_item.title = "Google Calendar connected ✓"
        except Exception as exc:
            self.status_item.title = "Calendar connection failed"
            rumps.notification(
                "Calendar Plane",
                "Google Calendar setup needed",
                str(exc),
            )

    def toggle_pause(self, _):
        self.paused = not self.paused
        self.pause_item.title = "Resume" if self.paused else "Pause"

    def fly_demo(self, _):
        self._fly("German Class 🇩🇪", dt.datetime.now(dt.timezone.utc) + dt.timedelta(minutes=5))

    def _fly(self, title, start):
        # AppKit UI work must happen on the main run loop; rumps callbacks already do.
        local = start.astimezone()
        event_time = local.strftime("%-I:%M %p")
        minutes = _minutes_until(start)
        self.overlay.fly(title, event_time, minutes, FLIGHT_SECONDS)

    def _tick(self, _timer):
        if self.paused:
            return
        if self.demo:
            self.demo = False
            self.fly_demo(None)
            return
        if not self.authorized:
            return

        try:
            event = self.calendar.next_event()
        except Exception as exc:
            self.status_item.title = "Calendar error — retrying…"
            print(f"[Calendar Plane] {exc}")
            return

        if not event:
            self.status_item.title = "No upcoming meetings"
            return

        start = event["_parsed_start"]
        minutes = _minutes_until(start)
        title = event.get("summary", "Upcoming meeting")
        event_id = event.get("id", f"{title}|{start.isoformat()}")

        self.status_item.title = f"Next: {title[:28]}"

        if 0 < (start - dt.datetime.now(start.tzinfo)).total_seconds() <= REMINDER_MINUTES * 60:
            if event_id not in self.seen:
                self.seen.add(event_id)
                self._fly(title, start)


def main():
    parser = argparse.ArgumentParser(description="Cute Google Calendar plane for macOS.")
    parser.add_argument("--demo", action="store_true", help="Fly immediately instead of waiting for a meeting.")
    args = parser.parse_args()
    CalendarPlaneApp(demo=args.demo).run()


if __name__ == "__main__":
    main()
