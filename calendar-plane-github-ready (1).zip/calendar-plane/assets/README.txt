plane.png is an extracted/cut-out sprite based on the plane illustration in the user-provided reference image.
The app draws the banner itself so the banner text can change with each calendar event.
