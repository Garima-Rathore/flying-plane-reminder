import datetime as dt
import os
from pathlib import Path
from typing import Optional

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

SCOPES = ["https://www.googleapis.com/auth/calendar.readonly"]
BASE_DIR = Path(__file__).resolve().parent
CREDENTIALS_FILE = BASE_DIR / "credentials.json"
TOKEN_FILE = BASE_DIR / "token.json"


def _parse_start(event: dict) -> Optional[dt.datetime]:
    start = event.get("start", {})
    value = start.get("dateTime")
    if not value:
        return None  # Ignore all-day events for this visual reminder.
    return dt.datetime.fromisoformat(value.replace("Z", "+00:00"))


class CalendarClient:
    def __init__(self) -> None:
        self.service = None

    def authorize(self):
        if not CREDENTIALS_FILE.exists():
            raise FileNotFoundError(
                "credentials.json is missing. Download a Desktop OAuth client "
                "from Google Cloud and put it in the project root."
            )

        creds = None
        if TOKEN_FILE.exists():
            creds = Credentials.from_authorized_user_file(str(TOKEN_FILE), SCOPES)

        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            else:
                flow = InstalledAppFlow.from_client_secrets_file(
                    str(CREDENTIALS_FILE), SCOPES
                )
                creds = flow.run_local_server(port=0)

            TOKEN_FILE.write_text(creds.to_json(), encoding="utf-8")

        self.service = build("calendar", "v3", credentials=creds, cache_discovery=False)
        return self

    def next_event(self, horizon_hours: int = 24) -> Optional[dict]:
        if self.service is None:
            raise RuntimeError("CalendarClient.authorize() must be called first.")

        now = dt.datetime.now(dt.timezone.utc)
        result = (
            self.service.events()
            .list(
                calendarId="primary",
                timeMin=now.isoformat(),
                timeMax=(now + dt.timedelta(hours=horizon_hours)).isoformat(),
                maxResults=25,
                singleEvents=True,
                orderBy="startTime",
            )
            .execute()
        )

        for event in result.get("items", []):
            if event.get("status") == "cancelled":
                continue
            start = _parse_start(event)
            if start is not None:
                event["_parsed_start"] = start
                return event

        return None
