#!/bin/zsh
set -e
cd "$(dirname "$0")"

echo "Creating virtual environment..."
python3 -m venv .venv
source .venv/bin/activate

echo "Installing dependencies..."
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

echo
echo "Calendar Plane is installed."
echo "1. Put your Google OAuth Desktop credentials at:"
echo "   $(pwd)/credentials.json"
echo "2. Then run:"
echo "   ./run.sh"
