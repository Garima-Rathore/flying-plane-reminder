from __future__ import annotations

import io
import math
import os
import time
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont
from Cocoa import (
    NSBackingStoreBuffered,
    NSColor,
    NSImage,
    NSImageView,
    NSMakeRect,
    NSPanel,
    NSStatusWindowLevel,
    NSWindowCollectionBehaviorCanJoinAllSpaces,
    NSWindowCollectionBehaviorFullScreenAuxiliary,
)
from Foundation import NSData, NSTimer


BASE_DIR = Path(__file__).resolve().parent
PLANE_PATH = BASE_DIR / "assets" / "plane.png"


def _font(size: int, bold: bool = False):
    candidates = []
    if bold:
        candidates += [
            "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
            "/System/Library/Fonts/Supplemental/Helvetica Bold.ttf",
        ]
    else:
        candidates += [
            "/System/Library/Fonts/Supplemental/Arial.ttf",
            "/System/Library/Fonts/Supplemental/Helvetica.ttf",
        ]
    for path in candidates:
        if os.path.exists(path):
            return ImageFont.truetype(path, size)
    return ImageFont.load_default()


def _rounded_banner(draw, box, radius=28):
    draw.rounded_rectangle(box, radius=radius, fill=(255, 246, 224, 255), outline=(88, 73, 65, 255), width=3)


def _make_banner(title: str, event_time: str, minutes: int) -> bytes:
    """Render the banner first, then place the plane over its left edge."""
    W, H = 980, 270
    canvas = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    draw = ImageDraw.Draw(canvas)

    # Banner sits behind the plane.
    banner = (210, 65, 955, 205)
    _rounded_banner(draw, banner)

    # Small pointed ends.
    draw.polygon([(210, 65), (175, 90), (210, 110)], fill=(255, 246, 224, 255), outline=(88, 73, 65, 255))
    draw.polygon([(955, 205), (985, 178), (955, 160)], fill=(255, 246, 224, 255), outline=(88, 73, 65, 255))

    # Decorative stitch/doodle lines.
    draw.arc((735, 115, 785, 170), 180, 330, fill=(235, 125, 145, 255), width=4)
    draw.ellipse((815, 128, 827, 140), fill=(245, 120, 145, 255))
    draw.ellipse((835, 110, 847, 122), fill=(245, 120, 145, 255))

    # Calendar icon.
    draw.rounded_rectangle((245, 95, 292, 145), radius=7, fill=(255, 225, 218, 255), outline=(90, 75, 70, 255), width=2)
    draw.rectangle((245, 95, 292, 109), fill=(247, 145, 145, 255))
    for x in (254, 267, 280):
        for y in (117, 130):
            draw.rounded_rectangle((x, y, x + 7, y + 7), radius=1, fill=(242, 125, 125, 255))

    title_font = _font(31, True)
    detail_font = _font(20, False)
    small_font = _font(18, True)

    # Keep very long event names from overflowing.
    max_width = 600
    title_text = title.strip() or "Upcoming meeting"
    while draw.textbbox((0, 0), title_text, font=title_font)[2] > max_width and len(title_text) > 12:
        title_text = title_text[:-4].rstrip() + "…"

    draw.text((315, 82), title_text, font=title_font, fill=(62, 52, 50, 255))
    draw.text((315, 125), f"{event_time}  •  in {max(0, minutes)} min", font=detail_font, fill=(95, 82, 77, 255))
    draw.text((315, 162), "Calendar Plane ✈", font=small_font, fill=(125, 91, 91, 255))

    # Two strings attach the banner to the plane.
    string_color = (90, 75, 68, 255)
    draw.line((185, 94, 210, 92), fill=string_color, width=3)
    draw.line((185, 165, 210, 178), fill=string_color, width=3)

    # Plane from the supplied reference is deliberately drawn last.
    plane = Image.open(PLANE_PATH).convert("RGBA")
    target_h = 190
    target_w = int(plane.width * target_h / plane.height)
    plane = plane.resize((target_w, target_h), Image.Resampling.LANCZOS)
    canvas.alpha_composite(plane, (0, 35))

    buf = io.BytesIO()
    canvas.save(buf, format="PNG")
    return buf.getvalue()


class PlaneOverlay:
    def __init__(self):
        self.window = None
        self.image_view = None
        self._timer = None

    def _nsimage(self, png_bytes: bytes):
        data = NSData.dataWithBytes_length_(png_bytes, len(png_bytes))
        return NSImage.alloc().initWithData_(data)

    def fly(self, title: str, event_time: str, minutes: int = 5, duration: float = 10.0):
        png = _make_banner(title, event_time, minutes)
        image = self._nsimage(png)
        size = image.size()

        # Hide the normal app window immediately and use a floating non-activating panel.
        frame = NSMakeRect(-size.width, 0, size.width, size.height)
        panel = NSPanel.alloc().initWithContentRect_styleMask_backing_defer_(
            frame,
            0,  # borderless
            NSBackingStoreBuffered,
            False,
        )
        panel.setOpaque_(False)
        panel.setBackgroundColor_(NSColor.clearColor())
        panel.setHasShadow_(False)
        panel.setLevel_(NSStatusWindowLevel)
        panel.setIgnoresMouseEvents_(True)
        panel.setHidesOnDeactivate_(False)
        panel.setCollectionBehavior_(
            NSWindowCollectionBehaviorCanJoinAllSpaces
            | NSWindowCollectionBehaviorFullScreenAuxiliary
        )

        view = NSImageView.alloc().initWithFrame_(NSMakeRect(0, 0, size.width, size.height))
        view.setImage_(image)
        view.setImageScaling_(1)  # NSImageScaleProportionallyUpOrDown
        panel.setContentView_(view)

        self.window = panel
        self.image_view = view

        screen = panel.screen() or NSScreen.mainScreen()
        visible = screen.visibleFrame()
        y = visible.origin.y + max(10, visible.size.height - size.height - 90)
        start_x = visible.origin.x - size.width
        end_x = visible.origin.x + visible.size.width + 20

        panel.setFrameOrigin_((start_x, y))
        panel.orderFrontRegardless()

        start = time.monotonic()
        fps = 60.0
        frame_delay = 1.0 / fps

        def tick(_timer):
            elapsed = time.monotonic() - start
            p = min(1.0, elapsed / max(0.1, duration))
            # Smooth ease-in-out motion.
            eased = 0.5 - 0.5 * math.cos(math.pi * p)
            x = start_x + (end_x - start_x) * eased
            panel.setFrameOrigin_((x, y))
            if p >= 1.0:
                panel.orderOut_(None)
                _timer.invalidate()
                self.window = None

        self._timer = NSTimer.scheduledTimerWithTimeInterval_target_selector_userInfo_repeats_(
            frame_delay, _TimerTarget(tick), "fire:", None, True
        )


class _TimerTarget:
    def __init__(self, callback):
        self.callback = callback

    def fire_(self, timer):
        self.callback(timer)
